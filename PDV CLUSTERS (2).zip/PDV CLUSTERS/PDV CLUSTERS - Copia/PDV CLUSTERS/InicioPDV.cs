﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PDV_CLUSTERS
{
    public partial class InicioPDV : Form
    {
        public InicioPDV()
        {
            InitializeComponent();
            customizarDesing();
        }
        private void customizarDesing()
        {
            panelSubmenuCadastro.Visible = false;
            panelSubmenuCaixa.Visible = false;
            panelSubmenuRelatorio.Visible = false;

        }
        private void hideSubmenu()
        {
            if (panelSubmenuCadastro.Visible == true)
                panelSubmenuCadastro.Visible = false;
            if (panelSubmenuCaixa.Visible == true)
                panelSubmenuCaixa.Visible = false;
            if (panelSubmenuRelatorio.Visible == true)
                panelSubmenuRelatorio.Visible = false;
        }
        private void showSubmenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubmenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            showSubmenu(panelSubmenuCadastro);
        }

        private void btVenda_Click(object sender, EventArgs e)
        {
            //mostrar algum formulario
            //o codigo vai aqui para o botao 
            //aqui vai a tela de venda em si.
            hideSubmenu();
        }

       
    }

}
